# Crop Recommendation System

## Project Overview
AI/ML-based web application for recommending suitable crops and fertilizers based on soil conditions, climate data, and crop requirements.

## Technology Stack
- Backend: Django 4.2+
- Database: SQLite (development) / PostgreSQL (production)
- ML: scikit-learn, pandas, numpy
- Frontend: HTML5, CSS3, JavaScript (Bootstrap 5)
- Authentication: Django Allauth

## Project Structure
```
crop_recommendation/
├── crop_recommendation/     # Main project directory
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
├── core/                    # Core application
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   ├── forms.py
│   ├── admin.py
│   ├── ml_models/          # ML model files
│   │   ├── crop_model.pkl
│   │   ├── fertilizer_model.pkl
│   │   └── model_utils.py
│   └── templates/          # HTML templates
│       ├── base.html
│       ├── home.html
│       ├── recommendation.html
│       └── dashboard.html
├── static/                 # Static files
│   ├── css/
│   └── js/
├── manage.py
└── requirements.txt
```

## Features
1. User Authentication (Registration, Login, Logout)
2. Soil Data Input Form
3. Climate Data Integration
4. Crop Recommendation Engine
5. Fertilizer Recommendation Engine
6. User Dashboard with History
7. Admin Panel for Data Management

## Database Models
- User (extended with Django Allauth)
- SoilData
- ClimateData
- Crop
- Fertilizer
- RecommendationHistory
