"""
Database Models for Crop Recommendation System

This module defines all the database models needed for:
- User management (extended from Django's AbstractUser)
- Crop information and requirements
- Fertilizer information
- Soil data storage
- Climate data storage
- Recommendation history tracking

Best Practices:
- Use proper field types and constraints
- Add helpful verbose names and help_text
- Implement __str__ methods for better admin experience
- Use choices for enumerated fields
- Add indexes for frequently queried fields
"""

from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


class User(AbstractUser):
    """
    Extended User model with additional fields for farmers/agricultural users.
    """
    USER_TYPE_CHOICES = [
        ('farmer', 'Farmer'),
        ('agriculturalist', 'Agriculturalist'),
        ('researcher', 'Researcher'),
        ('other', 'Other'),
    ]
    
    user_type = models.CharField(
        max_length=20,
        choices=USER_TYPE_CHOICES,
        default='farmer',
        help_text='Type of user'
    )
    phone = models.CharField(
        max_length=20,
        blank=True,
        help_text='Contact phone number'
    )
    address = models.TextField(
        blank=True,
        help_text='Farm or contact address'
    )
    latitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text='Latitude for location-based recommendations'
    )
    longitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text='Longitude for location-based recommendations'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'
    
    def __str__(self):
        return f"{self.username} ({self.get_user_type_display()})"


class Crop(models.Model):
    """
    Crop model containing information about different crops and their requirements.
    This serves as a reference for crop recommendations.
    """
    name = models.CharField(
        max_length=100,
        unique=True,
        help_text='Name of the crop'
    )
    category = models.CharField(
        max_length=50,
        help_text='Category (e.g., cereal, vegetable, fruit)'
    )
    
    # Soil requirements
    min_nitrogen = models.FloatField(
        help_text='Minimum nitrogen requirement (kg/ha)'
    )
    max_nitrogen = models.FloatField(
        help_text='Maximum nitrogen requirement (kg/ha)'
    )
    min_phosphorus = models.FloatField(
        help_text='Minimum phosphorus requirement (kg/ha)'
    )
    max_phosphorus = models.FloatField(
        help_text='Maximum phosphorus requirement (kg/ha)'
    )
    min_potassium = models.FloatField(
        help_text='Minimum potassium requirement (kg/ha)'
    )
    max_potassium = models.FloatField(
        help_text='Maximum potassium requirement (kg/ha)'
    )
    optimal_ph_min = models.FloatField(
        help_text='Minimum optimal pH level'
    )
    optimal_ph_max = models.FloatField(
        help_text='Maximum optimal pH level'
    )
    
    # Climate requirements
    min_temperature = models.FloatField(
        help_text='Minimum optimal temperature (°C)'
    )
    max_temperature = models.FloatField(
        help_text='Maximum optimal temperature (°C)'
    )
    min_rainfall = models.FloatField(
        help_text='Minimum rainfall requirement (mm)'
    )
    max_rainfall = models.FloatField(
        help_text='Maximum rainfall requirement (mm)'
    )
    min_humidity = models.FloatField(
        help_text='Minimum humidity requirement (%)'
    )
    max_humidity = models.FloatField(
        help_text='Maximum humidity requirement (%)'
    )
    
    # Growth characteristics
    growth_period_days = models.IntegerField(
        help_text='Average growth period in days'
    )
    water_requirement_mm = models.FloatField(
        help_text='Water requirement during growth period (mm)'
    )
    
    # Additional info
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to='crops/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Crop'
        verbose_name_plural = 'Crops'
        ordering = ['name']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['category']),
        ]
    
    def __str__(self):
        return self.name


class Fertilizer(models.Model):
    """
    Fertilizer model containing information about different fertilizers.
    """
    FERTILIZER_TYPE_CHOICES = [
        ('nitrogen', 'Nitrogen (N)'),
        ('phosphorus', 'Phosphorus (P)'),
        ('potassium', 'Potassium (K)'),
        ('npk', 'NPK Complex'),
        ('organic', 'Organic'),
        ('micronutrient', 'Micronutrient'),
        ('other', 'Other'),
    ]
    
    name = models.CharField(
        max_length=100,
        unique=True,
        help_text='Name of the fertilizer'
    )
    fertilizer_type = models.CharField(
        max_length=20,
        choices=FERTILIZER_TYPE_CHOICES,
        help_text='Type of fertilizer'
    )
    
    # Nutrient content (percentage)
    nitrogen_content = models.FloatField(
        default=0,
        help_text='Nitrogen content (%)'
    )
    phosphorus_content = models.FloatField(
        default=0,
        help_text='Phosphorus content (%)'
    )
    potassium_content = models.FloatField(
        default=0,
        help_text='Potassium content (%)'
    )
    
    # Application details
    application_method = models.TextField(
        help_text='Recommended application method'
    )
    application_rate = models.CharField(
        max_length=100,
        help_text='Recommended application rate'
    )
    timing = models.TextField(
        help_text='Best time to apply'
    )
    
    # Compatibility
    suitable_crops = models.ManyToManyField(
        'self',
        blank=True,
        help_text='Crops suitable for this fertilizer'
    )
    
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Fertilizer'
        verbose_name_plural = 'Fertilizers'
        ordering = ['name']
    
    def __str__(self):
        return f"{self.name} ({self.get_fertilizer_type_display()})"


class SoilData(models.Model):
    """
    Model for storing soil test results and analysis data.
    """
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='soil_data',
        help_text='User who owns this soil data'
    )
    
    # Location
    location_name = models.CharField(
        max_length=200,
        blank=True,
        help_text='Name of the location/field'
    )
    latitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True
    )
    longitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True
    )
    
    # Soil nutrients (kg/ha)
    nitrogen_content = models.FloatField(
        help_text='Nitrogen content (kg/ha)'
    )
    phosphorus_content = models.FloatField(
        help_text='Phosphorus content (kg/ha)'
    )
    potassium_content = models.FloatField(
        help_text='Potassium content (kg/ha)'
    )
    
    # Soil properties
    ph_level = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(14)],
        help_text='Soil pH level (0-14)'
    )
    organic_matter = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text='Organic matter content (%)'
    )
    soil_moisture = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text='Soil moisture content (%)'
    )
    soil_type = models.CharField(
        max_length=50,
        blank=True,
        help_text='Type of soil (clay, sandy, loamy, etc.)'
    )
    
    # Additional data
    test_date = models.DateField(
        help_text='Date of soil test'
    )
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Soil Data'
        verbose_name_plural = 'Soil Data'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['user']),
        ]
    
    def __str__(self):
        return f"Soil Data - {self.location_name or 'Unknown'} ({self.test_date})"


class ClimateData(models.Model):
    """
    Model for storing climate/weather data for a location.
    """
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='climate_data',
        help_text='User who owns this climate data'
    )
    
    # Location
    location_name = models.CharField(
        max_length=200,
        blank=True
    )
    latitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True
    )
    longitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True
    )
    
    # Climate parameters
    temperature = models.FloatField(
        help_text='Current temperature (°C)'
    )
    humidity = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text='Humidity (%)'
    )
    rainfall = models.FloatField(
        help_text='Rainfall (mm)'
    )
    wind_speed = models.FloatField(
        default=0,
        help_text='Wind speed (km/h)'
    )
    
    # Season/Time
    season = models.CharField(
        max_length=20,
        help_text='Current season'
    )
    data_date = models.DateField(
        help_text='Date of climate data'
    )
    
    # Additional
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Climate Data'
        verbose_name_plural = 'Climate Data'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['user']),
        ]
    
    def __str__(self):
        return f"Climate - {self.location_name or 'Unknown'} ({self.data_date})"


class RecommendationHistory(models.Model):
    """
    Model for storing recommendation history.
    Tracks all crop and fertilizer recommendations made.
    """
    RECOMMENDATION_TYPE_CHOICES = [
        ('crop', 'Crop Recommendation'),
        ('fertilizer', 'Fertilizer Recommendation'),
    ]
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='recommendations',
        help_text='User who received the recommendation'
    )
    
    recommendation_type = models.CharField(
        max_length=20,
        choices=RECOMMENDATION_TYPE_CHOICES,
        help_text='Type of recommendation'
    )
    
    # Input parameters (stored as JSON for flexibility)
    input_parameters = models.JSONField(
        help_text='Input parameters used for recommendation'
    )
    
    # Results
    recommended_crop = models.ForeignKey(
        Crop,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='recommendations'
    )
    recommended_fertilizer = models.ForeignKey(
        Fertilizer,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='recommendations'
    )
    
    # Confidence/score
    confidence_score = models.FloatField(
        null=True,
        blank=True,
        help_text='Confidence score of the recommendation (0-1)'
    )
    
    # Linked data
    soil_data = models.ForeignKey(
        SoilData,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='recommendations'
    )
    climate_data = models.ForeignKey(
        ClimateData,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='recommendations'
    )
    
    # Notes
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Recommendation History'
        verbose_name_plural = 'Recommendation Histories'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['user']),
            models.Index(fields=['recommendation_type']),
        ]
    
    def __str__(self):
        return f"{self.get_recommendation_type_display()} - {self.user.username} ({self.created_at.date()})"


# Signal handlers for creating related records
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """Create related profile data when user is created."""
    if created:
        # Can be extended to create default profiles or settings
        pass
