"""
API URL Configuration

REST API endpoints for crop and fertilizer recommendations.
"""

from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

urlpatterns = [
    # These are handled in core/urls.py with function-based views
    # but can be added here for API-only routing if needed
]
