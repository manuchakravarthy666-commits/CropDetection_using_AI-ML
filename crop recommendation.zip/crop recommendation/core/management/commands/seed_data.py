"""
Management command to seed initial data for the application.
"""
from django.core.management.base import BaseCommand
from core.models import Crop, Fertilizer


class Command(BaseCommand):
    help = 'Seeds the database with initial crop and fertilizer data'
    
    def handle(self, *args, **options):
        self.stdout.write('Seeding crops...')
        self._seed_crops()
        
        self.stdout.write('Seeding fertilizers...')
        self._seed_fertilizers()
        
        self.stdout.write(self.style.SUCCESS('Database seeded successfully!'))
    
    def _seed_crops(self):
        """Seed crop data."""
        crops_data = [
            {
                'name': 'Rice',
                'category': 'Cereal',
                'min_nitrogen': 50, 'max_nitrogen': 150,
                'min_phosphorus': 25, 'max_phosphorus': 75,
                'min_potassium': 30, 'max_potassium': 100,
                'optimal_ph_min': 5.5, 'optimal_ph_max': 7.0,
                'min_temperature': 20, 'max_temperature': 35,
                'min_rainfall': 1000, 'max_rainfall': 2500,
                'min_humidity': 70, 'max_humidity': 90,
                'growth_period_days': 120,
                'water_requirement_mm': 1200,
                'description': 'Staple food crop requiring high water'
            },
            {
                'name': 'Wheat',
                'category': 'Cereal',
                'min_nitrogen': 40, 'max_nitrogen': 120,
                'min_phosphorus': 20, 'max_phosphorus': 60,
                'min_potassium': 20, 'max_potassium': 80,
                'optimal_ph_min': 6.0, 'optimal_ph_max': 7.5,
                'min_temperature': 10, 'max_temperature': 25,
                'min_rainfall': 300, 'max_rainfall': 800,
                'min_humidity': 40, 'max_humidity': 70,
                'growth_period_days': 100,
                'water_requirement_mm': 450,
                'description': 'Major cereal crop for temperate regions'
            },
            {
                'name': 'Maize',
                'category': 'Cereal',
                'min_nitrogen': 80, 'max_nitrogen': 200,
                'min_phosphorus': 30, 'max_phosphorus': 90,
                'min_potassium': 30, 'max_potassium': 120,
                'optimal_ph_min': 5.8, 'optimal_ph_max': 7.0,
                'min_temperature': 18, 'max_temperature': 32,
                'min_rainfall': 500, 'max_rainfall': 1200,
                'min_humidity': 50, 'max_humidity': 80,
                'growth_period_days': 90,
                'water_requirement_mm': 500,
                'description': 'Versatile cereal used for food and feed'
            },
            {
                'name': 'Cotton',
                'category': 'Fiber',
                'min_nitrogen': 50, 'max_nitrogen': 150,
                'min_phosphorus': 20, 'max_phosphorus': 60,
                'min_potassium': 40, 'max_potassium': 120,
                'optimal_ph_min': 5.5, 'optimal_ph_max': 8.0,
                'min_temperature': 20, 'max_temperature': 35,
                'min_rainfall': 500, 'max_rainfall': 1000,
                'min_humidity': 40, 'max_humidity': 70,
                'growth_period_days': 150,
                'water_requirement_mm': 700,
                'description': 'Important fiber crop'
            },
            {
                'name': 'Sugarcane',
                'category': 'Cash Crop',
                'min_nitrogen': 100, 'max_nitrogen': 250,
                'min_phosphorus': 30, 'max_phosphorus': 100,
                'min_potassium': 50, 'max_potassium': 150,
                'optimal_ph_min': 6.0, 'optimal_ph_max': 7.5,
                'min_temperature': 20, 'max_temperature': 35,
                'min_rainfall': 1500, 'max_rainfall': 2500,
                'min_humidity': 60, 'max_humidity': 85,
                'growth_period_days': 365,
                'water_requirement_mm': 2000,
                'description': 'Tropical crop for sugar production'
            },
            {
                'name': 'Millet',
                'category': 'Cereal',
                'min_nitrogen': 20, 'max_nitrogen': 60,
                'min_phosphorus': 15, 'max_phosphorus': 40,
                'min_potassium': 15, 'max_potassium': 50,
                'optimal_ph_min': 5.5, 'optimal_ph_max': 7.5,
                'min_temperature': 25, 'max_temperature': 35,
                'min_rainfall': 200, 'max_rainfall': 600,
                'min_humidity': 30, 'max_humidity': 60,
                'growth_period_days': 60,
                'water_requirement_mm': 350,
                'description': 'Drought-resistant cereal'
            },
        ]
        
        for crop_data in crops_data:
            Crop.objects.get_or_create(
                name=crop_data['name'],
                defaults=crop_data
            )
        
        self.stdout.write(f'Created {len(crops_data)} crops')
    
    def _seed_fertilizers(self):
        """Seed fertilizer data."""
        fertilizers_data = [
            {
                'name': 'Urea',
                'fertilizer_type': 'nitrogen',
                'nitrogen_content': 46,
                'phosphorus_content': 0,
                'potassium_content': 0,
                'application_method': 'Broadcast or side dress',
                'application_rate': '100-200 kg/ha',
                'timing': 'Split application recommended',
                'description': 'High nitrogen fertilizer'
            },
            {
                'name': 'DAP',
                'fertilizer_type': 'phosphorus',
                'nitrogen_content': 18,
                'phosphorus_content': 46,
                'potassium_content': 0,
                'application_method': 'Band placement at sowing',
                'application_rate': '100-150 kg/ha',
                'timing': 'At sowing or as basal dose',
                'description': 'Common phosphorus fertilizer'
            },
            {
                'name': 'MOP',
                'fertilizer_type': 'potassium',
                'nitrogen_content': 0,
                'phosphorus_content': 0,
                'potassium_content': 60,
                'application_method': 'Broadcast and incorporate',
                'application_rate': '50-100 kg/ha',
                'timing': 'At sowing or as top dressing',
                'description': 'Potassium source for crops'
            },
            {
                'name': 'NPK 10-26-26',
                'fertilizer_type': 'npk',
                'nitrogen_content': 10,
                'phosphorus_content': 26,
                'potassium_content': 26,
                'application_method': 'Broadcast or band placement',
                'application_rate': '100-150 kg/ha',
                'timing': 'At sowing as basal dose',
                'description': 'Balanced NPK for flowering stage'
            },
            {
                'name': 'NPK 17-17-17',
                'fertilizer_type': 'npk',
                'nitrogen_content': 17,
                'phosphorus_content': 17,
                'potassium_content': 17,
                'application_method': 'Broadcast or band placement',
                'application_rate': '100-150 kg/ha',
                'timing': 'At sowing or as split application',
                'description': 'Balanced fertilizer for general use'
            },
            {
                'name': 'Vermicompost',
                'fertilizer_type': 'organic',
                'nitrogen_content': 1.5,
                'phosphorus_content': 1.0,
                'potassium_content': 1.5,
                'application_method': 'Broadcast and incorporate',
                'application_rate': '2-5 tons/ha',
                'timing': 'At land preparation',
                'description': 'Organic fertilizer from worm castings'
            },
        ]
        
        for fert_data in fertilizers_data:
            Fertilizer.objects.get_or_create(
                name=fert_data['name'],
                defaults=fert_data
            )
        
        self.stdout.write(f'Created {len(fertilizers_data)} fertilizers')
