"""
Machine Learning Models for Crop and Fertilizer Recommendation

This module contains:
1. Crop Recommendation Model - Random Forest classifier
2. Fertilizer Recommendation Model - Decision tree classifier
3. Data preprocessing utilities
4. Model training and evaluation functions

Best Practices:
- Use scikit-learn for ML models
- Implement proper data preprocessing
- Add logging for model predictions
- Handle edge cases and errors gracefully
- Save models using joblib for persistence
"""

import os
import logging
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import joblib
from pathlib import Path

# Setup logging
logger = logging.getLogger(__name__)

# Model directory
MODEL_DIR = Path(__file__).parent


class CropRecommendationModel:
    """
    Machine Learning model for recommending suitable crops based on
    soil conditions and climate data.
    
    Features used:
    - N, P, K (Nitrogen, Phosphorus, Potassium) levels
    - pH level
    - Temperature
    - Humidity
    - Rainfall
    """
    
    # Crop labels (0-21 for 22 different crops)
    CROP_LABELS = [
        'apple', 'banana', 'blackgram', 'chickpea', 'coconut',
        'coffee', 'cotton', 'grapes', 'jute', 'kidneybeans',
        'lentil', 'maize', 'mango', 'millet', 'mungbean',
        'muskmelon', 'orange', 'papaya', 'pigeonpeas', 'pomegranate',
        'rice', 'watermelon'
    ]
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.is_trained = False
        self._load_or_initialize()
    
    def _load_or_initialize(self):
        """Load existing model or initialize a new one."""
        model_path = MODEL_DIR / 'crop_model.pkl'
        scaler_path = MODEL_DIR / 'crop_scaler.pkl'
        encoder_path = MODEL_DIR / 'crop_encoder.pkl'
        
        # Always train fresh model on startup to avoid unfitted scaler issues
        self._initialize_new_model()
        self.train()
    
    def _initialize_new_model(self):
        """Initialize a new model with default parameters."""
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=15,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        self.label_encoder.fit(self.CROP_LABELS)
        self.is_trained = False
    
    def _create_sample_data(self):
        """
        Create sample training data for the crop recommendation model.
        In production, this should be replaced with actual data from the database.
        
        Features: [N, P, K, pH, temperature, humidity, rainfall]
        """
        # Sample data based on agricultural research
        data = {
            'N': [0]*50 + [20]*50 + [40]*50 + [60]*50 + [80]*50 + [100]*50 + [120]*50,
            'P': [0]*50 + [20]*50 + [40]*50 + [60]*50 + [80]*50 + [100]*50 + [120]*50,
            'K': [0]*50 + [20]*50 + [40]*50 + [60]*50 + [80]*50 + [100]*50 + [120]*50,
            'pH': [5.0]*50 + [5.5]*50 + [6.0]*50 + [6.5]*50 + [7.0]*50 + [7.5]*50 + [8.0]*50,
            'temperature': [15]*50 + [20]*50 + [25]*50 + [30]*50 + [35]*50 + [25]*50 + [20]*50,
            'humidity': [30]*50 + [40]*50 + [50]*50 + [60]*50 + [70]*50 + [80]*50 + [90]*50,
            'rainfall': [50]*50 + [100]*50 + [150]*50 + [200]*50 + [250]*50 + [300]*50 + [350]*50,
            'label': []
        }
        
        # Generate crop labels based on conditions
        for i in range(350):
            n, p, k = data['N'][i], data['P'][i], data['K'][i]
            ph, temp = data['pH'][i], data['temperature'][i]
            humidity, rainfall = data['humidity'][i], data['rainfall'][i]
            
            # Simple rule-based labeling for demonstration
            if ph < 6.0:
                data['label'].append('rice')
            elif ph > 7.5 and temp > 30:
                data['label'].append('cotton')
            elif rainfall > 200 and humidity > 70:
                data['label'].append('rice')
            elif rainfall < 100 and temp > 25:
                data['label'].append('millet')
            elif n > 80 and p > 60:
                data['label'].append('sugarcane')
            elif temp < 20:
                data['label'].append('wheat')
            else:
                data['label'].append('maize')
        
        return pd.DataFrame(data)
    
    def train(self, X=None, y=None):
        """
        Train the model with given data or sample data.
        
        Args:
            X: Feature matrix (optional)
            y: Target labels (optional)
        """
        if X is None or y is None:
            logger.info("Using sample data for training")
            df = self._create_sample_data()
            X = df[['N', 'P', 'K', 'pH', 'temperature', 'humidity', 'rainfall']].values
            y = df['label'].values
        
        # Encode labels
        y_encoded = self.label_encoder.fit_transform(y)
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train model
        self.model.fit(X_scaled, y_encoded)
        
        # Evaluate with cross-validation
        cv_scores = cross_val_score(self.model, X_scaled, y_encoded, cv=5)
        logger.info(f"Cross-validation accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")
        
        self.is_trained = True
        self._save_model()
        
        return cv_scores.mean()
    
    def _save_model(self):
        """Save the trained model to disk."""
        try:
            joblib.dump(self.model, MODEL_DIR / 'crop_model.pkl')
            joblib.dump(self.scaler, MODEL_DIR / 'crop_scaler.pkl')
            joblib.dump(self.label_encoder, MODEL_DIR / 'crop_encoder.pkl')
            logger.info("Model saved successfully")
        except Exception as e:
            logger.error(f"Error saving model: {e}")
    
    def predict(self, nitrogen, phosphorus, potassium, ph, temperature, humidity, rainfall):
        """
        Predict suitable crop(s) based on soil and climate conditions.
        
        Args:
            nitrogen: Nitrogen content (kg/ha)
            phosphorus: Phosphorus content (kg/ha)
            potassium: Potassium content (kg/ha)
            ph: Soil pH level
            temperature: Temperature (°C)
            humidity: Humidity (%)
            rainfall: Rainfall (mm)
        
        Returns:
            dict: Prediction results with crop name, confidence, and alternatives
        """
        try:
            # Prepare input features
            features = np.array([[
                nitrogen, phosphorus, potassium, ph,
                temperature, humidity, rainfall
            ]])
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Get prediction and probabilities
            prediction = self.model.predict(features_scaled)
            probabilities = self.model.predict_proba(features_scaled)
            
            # Decode prediction
            crop_name = self.label_encoder.inverse_transform(prediction)[0]
            
            # Get top 3 predictions
            top_indices = np.argsort(probabilities[0])[-3:][::-1]
            top_crops = []
            for idx in top_indices:
                crop = self.label_encoder.inverse_transform([idx])[0]
                prob = probabilities[0][idx]
                top_crops.append({
                    'crop': crop.capitalize(),
                    'confidence': round(prob * 100, 2)
                })
            
            result = {
                'success': True,
                'recommended_crop': crop_name.capitalize(),
                'confidence': round(probabilities[0].max() * 100, 2),
                'alternatives': top_crops
            }
            
            logger.info(f"Crop prediction: {result}")
            return result
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {
                'success': False,
                'error': str(e),
                'recommended_crop': None,
                'confidence': 0,
                'alternatives': []
            }
    
    def get_feature_importance(self):
        """Get feature importance scores."""
        if not self.is_trained:
            return None
        
        feature_names = ['N', 'P', 'K', 'pH', 'Temperature', 'Humidity', 'Rainfall']
        importances = self.model.feature_importances_
        
        return dict(zip(feature_names, importances))


class FertilizerRecommendationModel:
    """
    Machine Learning model for recommending appropriate fertilizers
    based on soil conditions and selected crop.
    """
    
    FERTILIZER_TYPES = [
        'Urea', 'DAP', 'MOP', 'SSP', 'NPK 10-26-26',
        'NPK 17-17-17', 'NPK 20-10-10', 'Vermicompost',
        'Compost', 'Bone Meal'
    ]
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.is_trained = False
        self._load_or_initialize()
    
    def _load_or_initialize(self):
        """Load existing model or initialize a new one."""
        model_path = MODEL_DIR / 'fertilizer_model.pkl'
        scaler_path = MODEL_DIR / 'fertilizer_scaler.pkl'
        encoder_path = MODEL_DIR / 'fertilizer_encoder.pkl'
        
        # Always train fresh model on startup
        self._initialize_new_model()
        self.train()
    
    def _initialize_new_model(self):
        """Initialize a new model."""
        self.model = GradientBoostingClassifier(
            n_estimators=100,
            max_depth=8,
            learning_rate=0.1,
            random_state=42
        )
        self.label_encoder.fit(self.FERTILIZER_TYPES)
        self.is_trained = False
    
    def _create_sample_data(self):
        """Create sample training data for fertilizer recommendation."""
        data = {
            'N': [], 'P': [], 'K': [], 'pH': [],
            'crop_type': [], 'fertilizer': []
        }
        
        # Generate sample data
        np.random.seed(42)
        n_samples = 500
        
        for _ in range(n_samples):
            n = np.random.choice([10, 40, 80, 120, 150])
            p = np.random.choice([10, 30, 60, 90])
            k = np.random.choice([10, 40, 80, 120])
            ph = np.random.choice([5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0])
            
            data['N'].append(n)
            data['P'].append(p)
            data['K'].append(k)
            data['pH'].append(ph)
            
            # Determine crop type based on NPK
            if n < 40:
                data['crop_type'].append(0)  # Low N requirement
            elif n < 80:
                data['crop_type'].append(1)  # Medium N requirement
            else:
                data['crop_type'].append(2)  # High N requirement
            
            # Determine fertilizer based on NPK deficiency
            if n < 40 and p < 30 and k < 40:
                data['fertilizer'].append('NPK 17-17-17')
            elif n < 40:
                data['fertilizer'].append('Urea')
            elif p < 30:
                data['fertilizer'].append('DAP')
            elif k < 40:
                data['fertilizer'].append('MOP')
            else:
                data['fertilizer'].append('NPK 20-10-10')
        
        return pd.DataFrame(data)
    
    def train(self, X=None, y=None):
        """Train the model."""
        if X is None or y is None:
            df = self._create_sample_data()
            X = df[['N', 'P', 'K', 'pH', 'crop_type']].values
            y = df['fertilizer'].values
        
        y_encoded = self.label_encoder.fit_transform(y)
        X_scaled = self.scaler.fit_transform(X)
        
        self.model.fit(X_scaled, y_encoded)
        
        cv_scores = cross_val_score(self.model, X_scaled, y_encoded, cv=5)
        logger.info(f"Fertilizer model CV accuracy: {cv_scores.mean():.4f}")
        
        self.is_trained = True
        self._save_model()
        
        return cv_scores.mean()
    
    def _save_model(self):
        """Save the trained model."""
        try:
            joblib.dump(self.model, MODEL_DIR / 'fertilizer_model.pkl')
            joblib.dump(self.scaler, MODEL_DIR / 'fertilizer_scaler.pkl')
            joblib.dump(self.label_encoder, MODEL_DIR / 'fertilizer_encoder.pkl')
            logger.info("Fertilizer model saved")
        except Exception as e:
            logger.error(f"Error saving fertilizer model: {e}")
    
    def predict(self, nitrogen, phosphorus, potassium, ph, crop_type=0):
        """
        Predict appropriate fertilizer.
        
        Args:
            nitrogen: Nitrogen content (kg/ha)
            phosphorus: Phosphorus content (kg/ha)
            potassium: Potassium content (kg/ha)
            ph: Soil pH level
            crop_type: Type of crop (0=low N, 1=medium N, 2=high N)
        
        Returns:
            dict: Prediction results
        """
        try:
            features = np.array([[
                nitrogen, phosphorus, potassium, ph, crop_type
            ]])
            
            features_scaled = self.scaler.transform(features)
            prediction = self.model.predict(features_scaled)
            probabilities = self.model.predict_proba(features_scaled)
            
            fertilizer_name = self.label_encoder.inverse_transform(prediction)[0]
            
            # Get alternative fertilizers
            top_indices = np.argsort(probabilities[0])[-3:][::-1]
            alternatives = []
            for idx in top_indices:
                fert = self.label_encoder.inverse_transform([idx])[0]
                prob = probabilities[0][idx]
                alternatives.append({
                    'fertilizer': fert,
                    'confidence': round(prob * 100, 2)
                })
            
            result = {
                'success': True,
                'recommended_fertilizer': fertilizer_name,
                'confidence': round(probabilities[0].max() * 100, 2),
                'alternatives': alternatives
            }
            
            logger.info(f"Fertilizer prediction: {result}")
            return result
            
        except Exception as e:
            logger.error(f"Fertilizer prediction error: {e}")
            return {
                'success': False,
                'error': str(e),
                'recommended_fertilizer': None,
                'confidence': 0,
                'alternatives': []
            }


# Global model instances (lazy loading)
_crop_model = None
_fertilizer_model = None


def get_crop_model():
    """Get or create crop recommendation model instance."""
    global _crop_model
    if _crop_model is None:
        _crop_model = CropRecommendationModel()
    return _crop_model


def get_fertilizer_model():
    """Get or create fertilizer recommendation model instance."""
    global _fertilizer_model
    if _fertilizer_model is None:
        _fertilizer_model = FertilizerRecommendationModel()
    return _fertilizer_model


def train_all_models():
    """Train all ML models."""
    crop_model = get_crop_model()
    fertilizer_model = get_fertilizer_model()
    
    crop_accuracy = crop_model.train()
    fertilizer_accuracy = fertilizer_model.train()
    
    return {
        'crop_model_accuracy': crop_accuracy,
        'fertilizer_model_accuracy': fertilizer_accuracy
    }
