"""
Django Forms for Crop Recommendation System

Forms for:
- User registration and profile editing
- Soil data input
- Climate data input
- Recommendation requests
"""

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import SoilData, ClimateData, RecommendationHistory

User = get_user_model()


class UserRegistrationForm(UserCreationForm):
    """
    Form for user registration with additional fields.
    """
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Email address'
        })
    )
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'First name'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Last name'
        })
    )
    user_type = forms.ChoiceField(
        choices=User.USER_TYPE_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    phone = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phone number'
        })
    )
    address = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'placeholder': 'Address',
            'rows': 3
        }),
        required=False
    )
    
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 
                  'user_type', 'phone', 'address', 'password1', 'password2')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Username'
        })
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirm password'
        })
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.user_type = self.cleaned_data['user_type']
        user.phone = self.cleaned_data.get('phone', '')
        user.address = self.cleaned_data.get('address', '')
        
        if commit:
            user.save()
        return user


class UserProfileForm(UserChangeForm):
    """
    Form for updating user profile.
    """
    password = None  # Hide password field
    
    class Meta:
        model = User
        fields = ('email', 'first_name', 'last_name', 'user_type', 
                  'phone', 'address', 'latitude', 'longitude')


class SoilDataForm(forms.ModelForm):
    """
    Form for inputting soil test data.
    """
    test_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'type': 'date',
            'class': 'form-control'
        }),
        help_text='Date of soil test'
    )
    
    class Meta:
        model = SoilData
        fields = [
            'location_name', 'latitude', 'longitude',
            'nitrogen_content', 'phosphorus_content', 'potassium_content',
            'ph_level', 'organic_matter', 'soil_moisture', 'soil_type',
            'test_date', 'notes'
        ]
        widgets = {
            'location_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter location/field name'
            }),
            'latitude': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Latitude (e.g., 40.7128)'
            }),
            'longitude': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Longitude (e.g., -74.0060)'
            }),
            'nitrogen_content': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nitrogen (kg/ha)',
                'step': '0.01'
            }),
            'phosphorus_content': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Phosphorus (kg/ha)',
                'step': '0.01'
            }),
            'potassium_content': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Potassium (kg/ha)',
                'step': '0.01'
            }),
            'ph_level': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'pH level (0-14)',
                'step': '0.1',
                'min': '0',
                'max': '14'
            }),
            'organic_matter': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Organic matter (%)',
                'step': '0.01',
                'max': '100'
            }),
            'soil_moisture': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Soil moisture (%)',
                'step': '0.01',
                'max': '100'
            }),
            'soil_type': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Soil type (clay, sandy, loamy, etc.)'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Additional notes',
                'rows': 3
            }),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        ph = cleaned_data.get('ph_level')
        
        if ph is not None and (ph < 0 or ph > 14):
            raise forms.ValidationError('pH level must be between 0 and 14')
        
        return cleaned_data


class ClimateDataForm(forms.ModelForm):
    """
    Form for inputting climate/weather data.
    """
    data_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'type': 'date',
            'class': 'form-control'
        }),
        help_text='Date of climate data'
    )
    
    SEASON_CHOICES = [
        ('spring', 'Spring'),
        ('summer', 'Summer'),
        ('autumn', 'Autumn'),
        ('winter', 'Winter'),
        ('monsoon', 'Monsoon'),
    ]
    
    season = forms.ChoiceField(
        choices=SEASON_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    class Meta:
        model = ClimateData
        fields = [
            'location_name', 'latitude', 'longitude',
            'temperature', 'humidity', 'rainfall', 'wind_speed',
            'season', 'data_date', 'notes'
        ]
        widgets = {
            'location_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter location name'
            }),
            'latitude': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Latitude',
                'step': '0.000001'
            }),
            'longitude': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Longitude',
                'step': '0.000001'
            }),
            'temperature': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Temperature (°C)',
                'step': '0.1'
            }),
            'humidity': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Humidity (%)',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'rainfall': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Rainfall (mm)',
                'step': '0.01'
            }),
            'wind_speed': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Wind speed (km/h)',
                'step': '0.1'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Additional notes',
                'rows': 3
            }),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        humidity = cleaned_data.get('humidity')
        
        if humidity is not None and (humidity < 0 or humidity > 100):
            raise forms.ValidationError('Humidity must be between 0 and 100')
        
        return cleaned_data


class QuickRecommendationForm(forms.Form):
    """
    Form for quick crop/fertilizer recommendation without saving data.
    Combines soil and climate inputs.
    """
    # Soil parameters
    nitrogen = forms.FloatField(
        label='Nitrogen (N)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Nitrogen content (kg/ha)',
            'step': '0.01'
        })
    )
    phosphorus = forms.FloatField(
        label='Phosphorus (P)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phosphorus content (kg/ha)',
            'step': '0.01'
        })
    )
    potassium = forms.FloatField(
        label='Potassium (K)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Potassium content (kg/ha)',
            'step': '0.01'
        })
    )
    ph_level = forms.FloatField(
        label='pH Level',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Soil pH (0-14)',
            'step': '0.1',
            'min': '0',
            'max': '14'
        })
    )
    
    # Climate parameters
    temperature = forms.FloatField(
        label='Temperature',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Temperature (°C)',
            'step': '0.1'
        })
    )
    humidity = forms.FloatField(
        label='Humidity',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Humidity (%)',
            'step': '0.1',
            'min': '0',
            'max': '100'
        })
    )
    rainfall = forms.FloatField(
        label='Rainfall',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Rainfall (mm)',
            'step': '0.01'
        })
    )
    
    # Optional: crop preference
    crop_preference = forms.CharField(
        label='Preferred Crop (Optional)',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter preferred crop name'
        })
    )
