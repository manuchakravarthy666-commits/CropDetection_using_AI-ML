"""
Custom Exception Handlers

Provides consistent error responses across the API.
"""

import logging
from rest_framework.views import exception_handler
from rest_framework.response import Response
from rest_framework import status

logger = logging.getLogger(__name__)


def custom_exception_handler(exc, context):
    """
    Custom exception handler for DRF views.
    Provides consistent error response format.
    """
    # Call REST framework's default exception handler first
    response = exception_handler(exc, context)
    
    if response is not None:
        # Custom error response format
        response.data = {
            'success': False,
            'error': {
                'code': response.status_code,
                'message': str(exc.detail) if hasattr(exc, 'detail') else str(exc),
            }
        }
        
        # Log the error
        logger.error(f"API Error: {exc} - Context: {context}")
    
    return response


class APIException(Exception):
    """Base API exception."""
    status_code = status.HTTP_400_BAD_REQUEST
    default_message = "An error occurred"
    
    def __init__(self, message=None):
        self.message = message or self.default_message
        super().__init__(self.message)


class ModelNotFoundException(APIException):
    """Exception raised when a model is not found."""
    status_code = status.HTTP_404_NOT_FOUND
    default_message = "Resource not found"


class PredictionException(APIException):
    """Exception raised during ML prediction."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_message = "Error during prediction"
