"""
Django Views for Crop Recommendation System

Views handle:
- Home page
- User registration
- Dashboard
- Soil data management
- Climate data management
- Crop and fertilizer recommendations
- API endpoints

Best Practices:
- Use class-based views (CBVs) for complex views
- Add proper error handling
- Implement authentication checks
- Use context processors for common data
- Add logging for debugging
"""

import logging
import os
from django.conf import settings
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.generic import TemplateView, FormView, ListView, DetailView
from django.utils.decorators import method_decorator
from django.http import JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from .models import (
    User, SoilData, ClimateData, RecommendationHistory,
    Crop, Fertilizer
)
from .forms import (
    UserRegistrationForm, UserProfileForm,
    SoilDataForm, ClimateDataForm, QuickRecommendationForm
)
from .ml_models import get_crop_model, get_fertilizer_model

# Setup logging
logger = logging.getLogger(__name__)


class HomeView(TemplateView):
    """
    Home page view - Landing page for the application.
    """
    template_name = 'core/home.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Crop Recommendation System'
        return context


class RegisterView(FormView):
    """
    User registration view.
    """
    template_name = 'core/register.html'
    form_class = UserRegistrationForm
    success_url = '/dashboard/'
    
    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        messages.success(self.request, 'Registration successful! Welcome to Crop Recommendation System.')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Register'
        return context


@method_decorator(login_required, name='dispatch')
class DashboardView(TemplateView):
    """
    User dashboard - Shows recommendation history and quick actions.
    """
    template_name = 'core/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Get recent recommendations
        recent_recommendations = RecommendationHistory.objects.filter(
            user=user
        )[:10]
        
        # Get soil data count
        soil_data_count = SoilData.objects.filter(user=user).count()
        
        # Get climate data count
        climate_data_count = ClimateData.objects.filter(user=user).count()
        
        context.update({
            'page_title': 'Dashboard',
            'user': user,
            'recent_recommendations': recent_recommendations,
            'soil_data_count': soil_data_count,
            'climate_data_count': climate_data_count,
        })
        return context


@method_decorator(login_required, name='dispatch')
class SoilDataListView(ListView):
    """
    List view for user's soil data entries.
    """
    model = SoilData
    template_name = 'core/soil_data_list.html'
    context_object_name = 'soil_data_list'
    paginate_by = 10
    
    def get_queryset(self):
        return SoilData.objects.filter(user=self.request.user).order_by('-created_at')


@method_decorator(login_required, name='dispatch')
class SoilDataCreateView(FormView):
    """
    Create new soil data entry.
    """
    template_name = 'core/soil_data_form.html'
    form_class = SoilDataForm
    success_url = '/soil-data/'
    
    def form_valid(self, form):
        soil_data = form.save(commit=False)
        soil_data.user = self.request.user
        soil_data.save()
        messages.success(self.request, 'Soil data saved successfully!')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Add Soil Data'
        context['action'] = 'Add'
        return context


@method_decorator(login_required, name='dispatch')
class SoilDataDetailView(DetailView):
    """
    View soil data details.
    """
    model = SoilData
    template_name = 'core/soil_data_detail.html'
    context_object_name = 'soil_data'
    
    def get_queryset(self):
        return SoilData.objects.filter(user=self.request.user)


@method_decorator(login_required, name='dispatch')
class ClimateDataListView(ListView):
    """
    List view for climate data.
    """
    model = ClimateData
    template_name = 'core/climate_data_list.html'
    context_object_name = 'climate_data_list'
    paginate_by = 10
    
    def get_queryset(self):
        return ClimateData.objects.filter(user=self.request.user).order_by('-created_at')


@method_decorator(login_required, name='dispatch')
class ClimateDataCreateView(FormView):
    """
    Create new climate data entry.
    """
    template_name = 'core/climate_data_form.html'
    form_class = ClimateDataForm
    success_url = '/climate-data/'
    
    def form_valid(self, form):
        climate_data = form.save(commit=False)
        climate_data.user = self.request.user
        climate_data.save()
        messages.success(self.request, 'Climate data saved successfully!')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Add Climate Data'
        context['action'] = 'Add'
        return context


class RecommendationView(TemplateView):
    """
    Main recommendation view - Provides crop and fertilizer recommendations.
    """
    template_name = 'core/recommendation.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Get Recommendation'
        context['recommendation_form'] = QuickRecommendationForm()
        return context
    
    def post(self, request, *args, **kwargs):
        form = QuickRecommendationForm(request.POST)
        
        if form.is_valid():
            # Extract form data
            nitrogen = form.cleaned_data['nitrogen']
            phosphorus = form.cleaned_data['phosphorus']
            potassium = form.cleaned_data['potassium']
            ph = form.cleaned_data['ph_level']
            temperature = form.cleaned_data['temperature']
            humidity = form.cleaned_data['humidity']
            rainfall = form.cleaned_data['rainfall']
            
            # Get ML models
            crop_model = get_crop_model()
            fertilizer_model = get_fertilizer_model()
            
            # Get predictions
            crop_result = crop_model.predict(
                nitrogen, phosphorus, potassium, ph,
                temperature, humidity, rainfall
            )
            
            # Determine crop type for fertilizer recommendation
            crop_type = 0  # Default
            if crop_result.get('recommended_crop'):
                crop_name = crop_result['recommended_crop'].lower()
                if crop_name in ['rice', 'wheat', 'maize']:
                    crop_type = 2  # High N requirement
                elif crop_name in ['cotton', 'sugarcane']:
                    crop_type = 1  # Medium N requirement
            
            fertilizer_result = fertilizer_model.predict(
                nitrogen, phosphorus, potassium, ph, crop_type
            )
            
            # Save to history if user is authenticated
            if request.user.is_authenticated:
                try:
                    history = RecommendationHistory.objects.create(
                        user=request.user,
                        recommendation_type='crop',
                        input_parameters={
                            'nitrogen': nitrogen,
                            'phosphorus': phosphorus,
                            'potassium': potassium,
                            'ph': ph,
                            'temperature': temperature,
                            'humidity': humidity,
                            'rainfall': rainfall
                        },
                        confidence_score=crop_result.get('confidence', 0) / 100
                    )
                    
                    # Also create fertilizer recommendation record
                    RecommendationHistory.objects.create(
                        user=request.user,
                        recommendation_type='fertilizer',
                        input_parameters={
                            'nitrogen': nitrogen,
                            'phosphorus': phosphorus,
                            'potassium': potassium,
                            'ph': ph,
                            'crop_type': crop_type
                        },
                        confidence_score=fertilizer_result.get('confidence', 0) / 100
                    )
                except Exception as e:
                    logger.error(f"Error saving recommendation history: {e}")
            
            context = self.get_context_data()
            context['form'] = form
            context['crop_result'] = crop_result
            context['fertilizer_result'] = fertilizer_result
            
            messages.success(request, 'Recommendation generated successfully!')
            return render(request, self.template_name, context)
        
        context = self.get_context_data()
        context['form'] = form
        messages.error(request, 'Please correct the errors in the form.')
        return render(request, self.template_name, context)


@login_required
def profile_view(request):
    """
    User profile view with editing capability.
    """
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.save():
            messages.success(request, 'Profile updated successfully!')
            return redirect('dashboard')
    else:
        form = UserProfileForm(instance=request.user)
    
    return render(request, 'core/profile.html', {
        'form': form,
        'page_title': 'Profile'
    })


def logout_view(request):
    """
    Logout view.
    """
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('home')


# API Views for AJAX requests
def api_recommend_crop(request):
    """
    API endpoint for crop recommendation.
    """
    if request.method == 'GET':
        try:
            nitrogen = float(request.GET.get('nitrogen', 0))
            phosphorus = float(request.GET.get('phosphorus', 0))
            potassium = float(request.GET.get('potassium', 0))
            ph = float(request.GET.get('ph', 7.0))
            temperature = float(request.GET.get('temperature', 25))
            humidity = float(request.GET.get('humidity', 50))
            rainfall = float(request.GET.get('rainfall', 100))
            
            crop_model = get_crop_model()
            result = crop_model.predict(
                nitrogen, phosphorus, potassium, ph,
                temperature, humidity, rainfall
            )
            
            return JsonResponse(result)
            
        except Exception as e:
            logger.error(f"API crop recommendation error: {e}")
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=400)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)


def api_recommend_fertilizer(request):
    """
    API endpoint for fertilizer recommendation.
    """
    if request.method == 'GET':
        try:
            nitrogen = float(request.GET.get('nitrogen', 0))
            phosphorus = float(request.GET.get('phosphorus', 0))
            potassium = float(request.GET.get('potassium', 0))
            ph = float(request.GET.get('ph', 7.0))
            crop_type = int(request.GET.get('crop_type', 0))
            
            fertilizer_model = get_fertilizer_model()
            result = fertilizer_model.predict(
                nitrogen, phosphorus, potassium, ph, crop_type
            )
            
            return JsonResponse(result)
            
        except Exception as e:
            logger.error(f"API fertilizer recommendation error: {e}")
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=400)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)


def api_train_models(request):
    """
    API endpoint to train ML models (admin only).
    """
    if not request.user.is_staff:
        return JsonResponse({'error': 'Permission denied'}, status=403)
    
    if request.method == 'POST':
        try:
            from .ml_models import train_all_models
            results = train_all_models()
            return JsonResponse({
                'success': True,
                'results': results
            })
        except Exception as e:
            logger.error(f"Model training error: {e}")
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)


class CropFertilizerRecommendationView(TemplateView):
    """
    Recommendation page using dataset from static folder.
    """
    template_name = 'crop_and_fertilizer.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Crop & Fertilizer Recommendation'
        return context
    
    def post(self, request, *args, **kwargs):
        # Get form data
        nitrogen = float(request.POST.get('nitrogen', 0))
        phosphorus = float(request.POST.get('phosphorus', 0))
        potassium = float(request.POST.get('potassium', 0))
        ph = float(request.POST.get('ph', 7.0))
        rainfall = float(request.POST.get('rainfall', 0))
        temperature = float(request.POST.get('temperature', 25))
        
        try:
            # Load the dataset
            import pandas as pd
            dataset_path = os.path.join(settings.BASE_DIR, 'static', 'Crop and fertilizer dataset.csv')
            df = pd.read_csv(dataset_path)
            
            # Filter data based on input (within reasonable range)
            # Allow ±10% tolerance for matching
            filtered = df[
                (df['Nitrogen'].between(nitrogen * 0.9, nitrogen * 1.1)) &
                (df['Phosphorus'].between(phosphorus * 0.9, phosphorus * 1.1)) &
                (df['Potassium'].between(potassium * 0.9, potassium * 1.1)) &
                (df['pH'].between(ph - 0.5, ph + 0.5)) &
                (df['Rainfall'].between(rainfall * 0.8, rainfall * 1.2)) &
                (df['Temperature'].between(temperature - 5, temperature + 5))
            ]
            
            if not filtered.empty:
                # Get unique records for display
                results = filtered.drop_duplicates(subset=['Crop', 'Fertilizer']).head(10)
                results_list = []
                for _, row in results.iterrows():
                    results_list.append({
                        'district': row['District_Name'],
                        'soil_color': row['Soil_color'],
                        'nitrogen': row['Nitrogen'],
                        'phosphorus': row['Phosphorus'],
                        'potassium': row['Potassium'],
                        'ph': row['pH'],
                        'rainfall': row['Rainfall'],
                        'temperature': row['Temperature'],
                        'crop': row['Crop'],
                        'fertilizer': row['Fertilizer'],
                        'link': row['Link']
                    })
                
                # Get the most common recommendation as primary
                crop_recommendation = filtered['Crop'].mode().iloc[0]
                fertilizer_recommendation = filtered['Fertilizer'].mode().iloc[0]
                
                result = {
                    'success': True,
                    'recommended_crop': crop_recommendation,
                    'recommended_fertilizer': fertilizer_recommendation,
                    'confidence': min(95, 60 + (len(filtered) / 10)),
                    'matching_records': len(filtered),
                    'results': results_list
                }
            else:
                # No exact match, try broader search
                broader = df[
                    (df['Nitrogen'].between(nitrogen * 0.7, nitrogen * 1.3)) &
                    (df['Phosphorus'].between(phosphorus * 0.7, phosphorus * 1.3)) &
                    (df['Potassium'].between(potassium * 0.7, potassium * 1.3))
                ]
                
                if not broader.empty:
                    results = broader.drop_duplicates(subset=['Crop', 'Fertilizer']).head(10)
                    results_list = []
                    for _, row in results.iterrows():
                        results_list.append({
                            'district': row['District_Name'],
                            'soil_color': row['Soil_color'],
                            'nitrogen': row['Nitrogen'],
                            'phosphorus': row['Phosphorus'],
                            'potassium': row['Potassium'],
                            'ph': row['pH'],
                            'rainfall': row['Rainfall'],
                            'temperature': row['Temperature'],
                            'crop': row['Crop'],
                            'fertilizer': row['Fertilizer'],
                            'link': row['Link']
                        })
                    
                    crop_recommendation = broader['Crop'].mode().iloc[0]
                    fertilizer_recommendation = broader['Fertilizer'].mode().iloc[0]
                    result = {
                        'success': True,
                        'recommended_crop': crop_recommendation,
                        'recommended_fertilizer': fertilizer_recommendation,
                        'confidence': 45,
                        'matching_records': len(broader),
                        'results': results_list,
                        'message': 'Found approximate matches. Results may vary.'
                    }
                else:
                    result = {
                        'success': False,
                        'error': 'No matching recommendations found for the given parameters.',
                        'recommended_crop': None,
                        'recommended_fertilizer': None,
                        'confidence': 0,
                        'results': []
                    }
            
        except Exception as e:
            logger.error(f"Dataset recommendation error: {e}")
            result = {
                'success': False,
                'error': str(e),
                'recommended_crop': None,
                'recommended_fertilizer': None,
                'confidence': 0,
                'results': []
            }
        
        context = self.get_context_data()
        context['result'] = result
        context['form_data'] = {
            'nitrogen': nitrogen,
            'phosphorus': phosphorus,
            'potassium': potassium,
            'ph': ph,
            'rainfall': rainfall,
            'temperature': temperature
        }
        return render(request, self.template_name, context)


# Error handlers
def error_404(request, exception):
    """Custom 404 error handler."""
    return render(request, 'core/errors/404.html', {
        'page_title': 'Page Not Found'
    }, status=404)


def error_500(request):
    """Custom 500 error handler."""
    return render(request, 'core/errors/500.html', {
        'page_title': 'Server Error'
    }, status=500)
