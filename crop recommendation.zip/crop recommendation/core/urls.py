"""
URL Configuration for Core Application

Maps URLs to views for:
- Home page
- User authentication
- Dashboard
- Soil data management
- Climate data management
- Recommendations
"""

from django.urls import path
from . import views

urlpatterns = [
    # Home and authentication
    path('', views.HomeView.as_view(), name='home'),
    path('register/', views.RegisterView.as_view(), name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    
    # Dashboard
    path('dashboard/', views.DashboardView.as_view(), name='dashboard'),
    
    # Soil data management
    path('soil-data/', views.SoilDataListView.as_view(), name='soil_data_list'),
    path('soil-data/add/', views.SoilDataCreateView.as_view(), name='soil_data_create'),
    path('soil-data/<int:pk>/', views.SoilDataDetailView.as_view(), name='soil_data_detail'),
    
    # Climate data management
    path('climate-data/', views.ClimateDataListView.as_view(), name='climate_data_list'),
    path('climate-data/add/', views.ClimateDataCreateView.as_view(), name='climate_data_create'),
    
    # Recommendations
    path('recommend/', views.RecommendationView.as_view(), name='recommendation'),
    path('crop-fertilizer/', views.CropFertilizerRecommendationView.as_view(), name='crop_fertilizer'),
    
    # API endpoints
    path('api/crop-recommend/', views.api_recommend_crop, name='api_crop_recommend'),
    path('api/fertilizer-recommend/', views.api_recommend_fertilizer, name='api_fertilizer_recommend'),
    path('api/train-models/', views.api_train_models, name='api_train_models'),
]
