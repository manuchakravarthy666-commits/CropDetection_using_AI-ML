"""
Django Admin Configuration

Customizes the admin interface for managing:
- Users
- Soil data
- Climate data
- Recommendations
- Crops and Fertilizers
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User, SoilData, ClimateData, RecommendationHistory,
    Crop, Fertilizer
)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Custom User admin with additional fields."""
    list_display = ('username', 'email', 'first_name', 'last_name', 
                    'user_type', 'is_staff', 'is_active')
    list_filter = ('user_type', 'is_staff', 'is_active')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)
    
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Additional Info', {
            'fields': ('user_type', 'phone', 'address', 'latitude', 'longitude')
        }),
    )
    
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('Additional Info', {
            'fields': ('user_type', 'phone', 'address')
        }),
    )


@admin.register(SoilData)
class SoilDataAdmin(admin.ModelAdmin):
    """Admin for soil data."""
    list_display = ('user', 'location_name', 'nitrogen_content', 
                    'phosphorus_content', 'potassium_content', 
                    'ph_level', 'test_date')
    list_filter = ('test_date', 'soil_type')
    search_fields = ('user__username', 'location_name')


@admin.register(ClimateData)
class ClimateDataAdmin(admin.ModelAdmin):
    """Admin for climate data."""
    list_display = ('user', 'location_name', 'temperature', 
                    'humidity', 'rainfall', 'season', 'data_date')
    list_filter = ('season', 'data_date')
    search_fields = ('user__username', 'location_name')


@admin.register(RecommendationHistory)
class RecommendationHistoryAdmin(admin.ModelAdmin):
    """Admin for recommendation history."""
    list_display = ('user', 'recommendation_type', 'confidence_score', 
                    'created_at')
    list_filter = ('recommendation_type', 'created_at')
    search_fields = ('user__username',)


@admin.register(Crop)
class CropAdmin(admin.ModelAdmin):
    """Admin for crop data."""
    list_display = ('name', 'category', 'growth_period_days')
    list_filter = ('category',)
    search_fields = ('name', 'category')
    ordering = ('name',)


@admin.register(Fertilizer)
class FertilizerAdmin(admin.ModelAdmin):
    """Admin for fertilizer data."""
    list_display = ('name', 'fertilizer_type', 'nitrogen_content', 
                    'phosphorus_content', 'potassium_content')
    list_filter = ('fertilizer_type',)
    search_fields = ('name',)
    ordering = ('name',)
