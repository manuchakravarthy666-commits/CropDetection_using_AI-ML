# Crop Recommendation System
# Main Django Project Package
