# Core templates
